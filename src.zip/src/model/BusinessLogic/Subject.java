package model.BusinessLogic;

import java.util.ArrayList;
import java.util.List;


import model.BusinessLogic.Student;

public class Subject {
	private int subjectId;
	private String className;
	private String classRoom;
	private int teacher;
	private List<Student> students;

	public Subject(int subjectId, String className, String classRoom, int teacher, List<Student> students) {
		this.subjectId = subjectId;
		this.className = className;
		this.classRoom = classRoom;
		this.teacher = teacher;
		this.students = students;

	}

	public int getSubjectId() {
		return subjectId;
	}
	
	

	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getClassRoom() {
		return classRoom;
	}

	public void setClassRoom(String classRoom) {
		this.classRoom = classRoom;
	}

	public int getTeacher() {
		return teacher;
	}

	public void setTeacher(int teacher) {
		this.teacher = teacher;
	}

	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}


	public void addStudent (Student student) {
		students.add(student);
		
	}
	
	
	@Override
	public String toString() {
		return "Class name: " + getClassName() + " Class Room: " + getClassRoom() + " Teacher: " + teacher
				+ "\nStudents" + getStudents();
	}

}
