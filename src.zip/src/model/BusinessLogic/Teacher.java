package model.BusinessLogic;

public abstract class Teacher extends Person {
	private double salary;

	public Teacher(int id, String name, double salary ) {
		super(id, name);
		this.salary = salary;
	}

	protected double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public abstract double totalSalary();

}
