package model.BusinessLogic;

public class PartTimeTeacher extends Teacher {
	private int hoursPerWeek;

	public PartTimeTeacher(int id, String name, double salary, int hoursPerWeek) {
		super(id, name, salary);
		this.hoursPerWeek = hoursPerWeek;

	}

	@Override
	public double totalSalary() {
		return this.getSalary() * hoursPerWeek;
	}

	@Override
	public String toString() {
		return "Teacher Id: " + getId() + " Name: " + getName() + " Salary: " + getSalary()
				+ " Hours per Week: " + hoursPerWeek;
	}

}
