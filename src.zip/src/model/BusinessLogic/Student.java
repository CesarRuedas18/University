package model.BusinessLogic;

import java.util.List;

public class Student extends Person {

	private int age;
	private List<String> subjects;

	public Student(int id, String name, int age) {
		super(id, name);
		this.age = age;

	}
	
	
	public Student(int id, String name, int age, List<String> subjects) {
		super(id, name);
		this.age = age;
		this.subjects = subjects;

	}
	
	
	

	public void setSubjects(List<String> subjects) {
		this.subjects = subjects;
	}



	public List<String> getSubjets() {
		return subjects;
	}

	public void addSubjets(String subject) {
		subjects.add( subject);	
	//	subjects = subject;
	}
	

	public List<String> getSubjects() {
		return subjects;
	}



	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	
	
	@Override
	public String toString() {
		return "Student Id: " + getId() + " Name: " + getName() + " Age: " + getAge() ;
		//+ "   Classes"+ getSubjets();
	}
	
	
	public String showStudentSubjects() {
		
		return "Classes: "+ getSubjets() ;
	}





}
