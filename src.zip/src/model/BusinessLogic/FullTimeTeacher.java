package model.BusinessLogic;

public class FullTimeTeacher extends Teacher {
	private int experienceYears;
	
	public FullTimeTeacher(int id, String name, double salary, int experienceYears) {
		super(id, name, salary);
		this.experienceYears = experienceYears;
	}
	
	
	
	public int getExperienceYears() {
		return experienceYears;
	}

	public void setExperienceYears(int experienceYears) {
		this.experienceYears = experienceYears;
	}
	

	@Override
	public double totalSalary() {
		return  (experienceYears * this.getSalary() * 1.1);
	}

	@Override
	public String toString() {
		return "TeacherId: " + getId() + " Name: " + getName() + " Salary: " + getSalary()
				+ " Experience Years: " + experienceYears;
	}

}
