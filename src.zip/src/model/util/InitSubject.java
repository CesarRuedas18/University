package model.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import model.BusinessLogic.FullTimeTeacher;
import model.BusinessLogic.PartTimeTeacher;
import model.BusinessLogic.Student;
import model.BusinessLogic.Subject;

public class InitSubject {
	static InitPersons pers = new InitPersons();
	static List<Subject> mySubjects = new ArrayList<>();

	private static Scanner sn;

	public static void createSubjet() {
		Subject subject = new Subject(subjectID(), className(), classRoom(), teacherForClass(),
				selectStudent(className()));
		mySubjects.add(subject);
	}

	public static List<Student> selectStudent(String classname) {
		Student student;
		Scanner sn = new Scanner(System.in);
		boolean exit = false;
		List<String> idSubjetList = new ArrayList<>();
		idSubjetList.add(classname);

		List<Student> onlyIdStudnet = new ArrayList<>();
		int idStudentSelect = 1;
		sn = new Scanner(System.in);

		while (idStudentSelect != 0) {
			int index = 1;
			System.out.println();
			for (Student i : InitPersons.myStudent) {
				System.out.println((index++) + ". Student Id: " + i.getId() + " Name: " + i.getName());
			}

			System.out.print("Choose the student, Type 0 to Exit  = ");
			idStudentSelect = sn.nextInt();

			for (int i = 0; i < InitPersons.myStudent.size(); i++) {

				if ((i + 1) == idStudentSelect) {
					onlyIdStudnet.add(InitPersons.myStudent.get(idStudentSelect - 1));

					InitPersons.myStudent.get(idStudentSelect - 1).setSubjects(idSubjetList);
				}
			}
		}
		return onlyIdStudnet;

	}

	private static int subjectID() {
		int subjectID = mySubjects.size() + 1;
		return subjectID;
	}

	private static String className() {
		sn = new Scanner(System.in);
		System.out.print("Please, Type the class name = ");
		String className = sn.nextLine();
		return className;
	}

	private static String classRoom() {
		sn = new Scanner(System.in);
		System.out.print("Please, Type the class Room = ");
		String classRoom = sn.nextLine();
		return classRoom;

	}

	private static int teacherForClass() {
		int count = 0;
		sn = new Scanner(System.in);
		System.out.println();
		for (FullTimeTeacher i : InitPersons.myFullTimeTeacher) {
			count++;
			System.out.println((count) + ". Teacher id = " + i.getId() + " teacher name = " + i.getName());
		}
		for (PartTimeTeacher i : InitPersons.myPartTimeTeacher) {
			count++;
			System.out.println((count) + ". Teacher id = " + i.getId() + " teacher name = " + i.getName());
		}

		System.out.print("Please, Select a teacher from 1 to " + count + " = --> ");
		int teacher = sn.nextInt();

		if (teacher > 0 && teacher < InitPersons.myFullTimeTeacher.size() + InitPersons.myPartTimeTeacher.size()) {

			for (int k = 0; k < InitPersons.myFullTimeTeacher.size(); k++) {
				if ((k + 1) == teacher) {
					int x = InitPersons.myFullTimeTeacher.get(teacher - 1).getId();
					return x;
				}

			}
			teacher = teacher - InitPersons.myFullTimeTeacher.size();

			for (int k = 0; k < InitPersons.myPartTimeTeacher.size(); k++) {

				if ((k + 1) == teacher) {
					int x = InitPersons.myPartTimeTeacher.get(teacher - 1).getId();
					return x;
				}

			}
		} else
			teacher = 0;
		return teacher;
	}

	public static List<Subject> initSubejet() {
		Subject class1 = new Subject(1, "Database", "CR-01", 1301, getStudens1("Database"));
		Subject class2 = new Subject(2, "Calculation 1", "CR-02", 1302, getStudens2("Calculation 1"));
		Subject class3 = new Subject(3, "Introduction to engineering", "CR-03", 1401,
				getStudens3("Introduction to engineering"));
		Subject class4 = new Subject(4, "Operating systems", "CR-04", 1402, getStudens4("Operating systems"));
		mySubjects.add(class1);
		mySubjects.add(class2);
		mySubjects.add(class3);
		mySubjects.add(class4);
		return mySubjects;
	}

	private static List<Student> getStudens1(String classname) {
		List<String> subjetId = new ArrayList<>();
		subjetId.add(classname);

		Student student;
		List<Student> Students = new ArrayList<>();
		for (Student i : InitPersons.myStudent) {
			if (i.getAge() >= 30 && i.getAge() < 40) {
				student = new Student(i.getId(), i.getName(), i.getAge());
				Students.add(student);
				i.setSubjects(subjetId);

			}
		}
		return Students;
	}

	private static List<Student> getStudens2(String classname) {
		List<String> subjetId = new ArrayList<>();
		subjetId.add(classname);

		Student student;
		List<Student> Students = new ArrayList<>();
		for (Student i : InitPersons.myStudent) {
			if (i.getAge() < 30) {
				student = new Student(i.getId(), i.getName(), i.getAge());
				Students.add(student);
				i.setSubjects(subjetId);
			}
		}
		return Students;
	}

	private static List<Student> getStudens3(String classname) {
		List<String> subjetId = new ArrayList<>();
		subjetId.add(classname);
		Student student;
		List<Student> Students = new ArrayList<>();
		for (Student i : InitPersons.myStudent) {
			if (i.getAge() >= 30 && i.getAge() < 40) {
				student = new Student(i.getId(), i.getName(), i.getAge());

				Students.add(student);
				i.setSubjects(subjetId);
			}
		}
		return Students;
	}

	private static List<Student> getStudens4(String classname) {
		List<String> subjetId = new ArrayList<>();
		subjetId.add(classname);
		Student student;
		List<Student> Students = new ArrayList<>();
		for (Student i : InitPersons.myStudent) {
			if (i.getAge() < 30) {
				student = new Student(i.getId(), i.getName(), i.getAge());
				Students.add(student);
				i.setSubjects(subjetId);
			}
		}
		return Students;
	}

	public static void showOnlyClasses() {
		StringBuilder classesBuilder = new StringBuilder("");
		int index = 0;
		System.out.println("----------All classes------------------");
		for (Subject i : mySubjects) {
			index++;
			classesBuilder.append(index + ". " + i.getClassName() + "\n");
		}
		classesBuilder.append((index + 1) + ". Exit the submenu");

		sn = new Scanner(System.in);
		boolean salir = false;
		int option;
		while (!salir) {
			System.out.println(classesBuilder.toString());
			System.out.print("Select an option =  -->");
			option = sn.nextInt();
			if (option == index + 1) {
				break;
			}

			else if (option >= index + 1) {
				System.out.println("The selected option is invalid");
				break;
			} else {
				System.out.println(showSubjet(String.valueOf(option)));
			}
		} // end while
	}

	public static String showSubjet(String lectureOption) {
		String result = new String("----------All classes------------------");
		int key = Integer.parseInt(lectureOption);

		System.out.println(mySubjects.get(key - 1).toString());
		int tech = mySubjects.get(key - 1).getTeacher();

		// Busco el profesor de la clase
		for (FullTimeTeacher i : InitPersons.myFullTimeTeacher) {
			if (i.getId() == tech) {
				System.out.println("Class by Professor " + i.getName());
			}
		}

		for (PartTimeTeacher i : InitPersons.myPartTimeTeacher) {
			if (i.getId() == tech) {
				System.out.println("Class by Professor " + i.getName());
			}
		}

		return result;
	}

	public static void showClassesAddSudent(int iD, String name, int age) {
		int index = 0;
		int option;
		String className = null;
		System.out.println("\nSelect the class to which the student wants to assign--");
		for (Subject i : mySubjects) {
			index++;
			System.out.println(index + ". " + i.getClassName());
			className = i.getClassName();
		}
		System.out.print("Select an option = ");
		sn = new Scanner(System.in);
		boolean salir = false;
		while (!salir) {
			option = sn.nextInt();
			if (option >= index + 1) {
				System.out.println("The typed option is not valid and returns to the main menu");
				break;
			} else {

				List<Student> students = new ArrayList<>();

				Student student = new Student(iD, name, age);
				students.add(student);

				List<String> idSubjetList = new ArrayList<>();
				for (Subject i : mySubjects) {
					if (i.getSubjectId() == option) {
						idSubjetList.add(i.getClassName());

						i.getStudents().addAll(students);

						for (Student k : InitPersons.myStudent) {
							if (k.getId() == iD) {
								k.setSubjects(idSubjetList);
							}

							// break;
						}
					}
					// break;
				}
				break;
			}
		}
	}

	public static void printAllSubjets() {
		for (Subject i : mySubjects) {
			System.out.println(i.toString());
		}
	}

}
