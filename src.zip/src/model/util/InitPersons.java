package model.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import model.BusinessLogic.FullTimeTeacher;
import model.BusinessLogic.PartTimeTeacher;
import model.BusinessLogic.Student;
import model.BusinessLogic.Subject;

public class InitPersons {

	private static Common common = new Common();
	static List<Student> myStudent = new ArrayList<>();
	static List<FullTimeTeacher> myFullTimeTeacher = new ArrayList<>();
	static List<PartTimeTeacher> myPartTimeTeacher = new ArrayList<>();
	static InitSubject mySubjet = new InitSubject();
	private static Scanner sn;
	

	

	public static void subjectWhereStudentIs() {
		sn = new Scanner(System.in);
		int countStudent = 1; 
		for (Student i : myStudent) {
			System.out.println((countStudent++) +". Student ID = " + i.getId() + ", Student Name = " + i.getName());
		}

		System.out.print("Choose the student code = ");
		int studentID = sn.nextInt();

		for (Student i : myStudent) {
			if (i.getId() == studentID) {
				System.out.println("Classes in which  " + i.getName() + " is enrolled ");
				System.out.println(i.showStudentSubjects()+" ");

			}
		}

	}

	public static boolean searchStudent(int idStudent) {
		for (Student i : myStudent) {
			if (i.getId() == idStudent) {
				return true;
			}
		}
		return false;
	}

	public static void addStudent() {
		sn = new Scanner(System.in);

		System.out.println("Enter the student information to create");
		System.out.print("Sudent ID = ");
		int iD = sn.nextInt();

		if (searchStudent(iD)) {
			System.out.println("The student already exist");
		} else {

			sn.nextLine();
			System.out.print("Sudent name: ");
			String name = sn.nextLine();
			System.out.print("Sudent age: ");
			int age = sn.nextInt();
			Student e = new Student(iD, name, age);
			myStudent.add(e);

			InitSubject.showClassesAddSudent(iD, name, age);

		}
	}

	public static List<Student> readStudent() {
		List<String> lines = common.readFile("studentsList");
		for (String line : lines) {
			String[] values = line.split(",");
			int id = Integer.parseInt(values[0]);
			int age = Integer.parseInt(values[2]);
			Student stud = new Student(id, values[1], age);
			myStudent.add(stud);
		}
		return myStudent;
	}


	
	
	public static List<FullTimeTeacher> readFullTimeTeacher() {
		List<String> lines = common.readFile("fullTimeTeacherList");
		for (String line : lines) {
			String[] values = line.split(",");
			int id = Integer.parseInt(values[0]);
			double salary = Double.parseDouble(values[2]);
			int experienceYears = Integer.parseInt(values[3]);
			FullTimeTeacher FTT = new FullTimeTeacher(id, values[1], salary, experienceYears);
			myFullTimeTeacher.add(FTT);
		}
		return myFullTimeTeacher;
	}

	public static List<PartTimeTeacher> readPartTimeTeacher() {
		List<String> lines = common.readFile("partTimeTeacherList");
		for (String line : lines) {
			String[] values = line.split(",");
			int id = Integer.parseInt(values[0]);
			double salary = Double.parseDouble(values[2]);
			int hoursPerWeek = Integer.parseInt(values[3]);
			PartTimeTeacher PTT = new PartTimeTeacher(id, values[1], salary, hoursPerWeek);
			myPartTimeTeacher.add(PTT);
		}
		return myPartTimeTeacher;
	}

	public static void printAllStudents() {
		System.out.println("---------------Students---------------");
		for (Student i : myStudent) {
			System.out.println(i.toString());
		}
		System.out.println();
	}

	public static void printAllFullTimeTeacher() {
		System.out.println("---Full Time Teachers---");
		for (FullTimeTeacher i : myFullTimeTeacher) {
			System.out.println(i.toString());
			System.out.println("Total Salary: " + i.totalSalary());
		}
		System.out.println();
	}

	public static void printAllPartTimeTeacher() {
		System.out.println("---Part Time Teachers---");
		for (PartTimeTeacher i : myPartTimeTeacher) {
			System.out.println(i.toString());
			System.out.println("Total Salary: " + i.totalSalary());

		}
		System.out.println();
	}

}
