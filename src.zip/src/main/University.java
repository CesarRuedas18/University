package main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import model.BusinessLogic.Student;
import model.util.InitPersons;
import model.util.InitSubject;

public class University {
	static InitPersons pers = new InitPersons();
	static InitSubject subj = new InitSubject();
	static List<Student> myStudent = new ArrayList<>();
	private static Scanner sn;

	public static void main(String args[]) {
		InitPersons.readStudent();
		InitPersons.readFullTimeTeacher();
		InitPersons.readPartTimeTeacher();
		InitSubject.initSubejet();

		showMenu();

	}

	private static void showMenu() {
		sn = new Scanner(System.in);
		boolean exit = false;
		int optionM;

		while (!exit) {

			System.out.println("\n1. Print all the professors with its data");
			System.out.println(
					"2. Print all the classes and a submenu to select a class in order to print the class data including its teacher and students");
			System.out.println("3. Create a new student and add it to an existing class");
			System.out.println("4. Create a new class and add a teacher, students and its relevant data");
			System.out.println("5. List all the classes in which a given student is included");
			System.out.println("6. Exit");

			System.out.print("Type an Option number =  ");
			optionM = sn.nextInt();

			switch (optionM) {
			case 1:
				InitPersons.printAllFullTimeTeacher();
				InitPersons.printAllPartTimeTeacher();
			//	 InitPersons.printAllStudents();
				break;

			case 2:

				InitSubject.showOnlyClasses();

				break;
			case 3:
				InitPersons.addStudent();

				break;

			case 4:
				InitSubject.createSubjet();
				break;

			case 5:
				InitPersons.subjectWhereStudentIs();
				break;

			case 6:
				exit = true;
				break;
			default:
				System.out.println("Only numbers between 1 to 6");
			}

		}

	}

}
